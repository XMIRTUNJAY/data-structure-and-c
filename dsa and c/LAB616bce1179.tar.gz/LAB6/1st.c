/* A complete working C program to demonstrate ROTATION methods IN DLL*/

#include<stdio.h>
#include<stdlib.h>

struct node
{
  int data;
  struct node *next;
  struct node *prev;
}*head=NULL,*last,*newnode,*delnode;

void getnode()
{
  newnode=(struct node*)malloc(sizeof(struct node));
}

void readnode()
{
  int d;
  printf("Enter the data:");
  scanf("%d",&d);
  newnode->data=d;
  newnode->prev=newnode;
  newnode->next=newnode;
}

void insertf()
{
  getnode();
  readnode();
  if(head==NULL)
  {
    head=last=newnode;
    head->prev=NULL;
    last->next=NULL;
  }
  else
  {
    head->prev=newnode;
    newnode->next=head;
    newnode->prev=NULL;
    head=newnode;
  }
}

void inserte()
{
  getnode();
  readnode();
  if(head==NULL)
  {
    head=last=newnode;
    head->prev=NULL;
    last->next=NULL;
  }
  else
  {
    last->next=newnode;
    newnode->next=NULL;
    newnode->prev=last;
    last=newnode;
  }
}

int delf()
{
  if(head==NULL)
  {
    printf("List is Empty");
    return 0;
  }
  else
  {
    delnode=head;
    head=head->next;
    head->prev=NULL;
    return(delnode->data);
   }
}

int dele()
{
  if(head==NULL)
  {
    printf("List is Empty");
    return 0;
  }
  else
  {
    delnode=last;
    last=last->prev;
    last->next=NULL;
    return(delnode->data);
   }
}
  
  
void rotate(int k)
{
     if (k == 0)
       return;
    struct node *current = head;
    int count = 1;
    while (count < k && current != NULL)
    {
        current = current->next;
        count++;
    }
    if (current == NULL)
        return;
    struct node *kthNode = current;
    while (current->next != NULL)
        current = current->next;
    current->next = head;
    head= kthNode->next;
    kthNode->next = NULL;
}
      
void display()
{
 struct node *trav=head;
 while(trav!=NULL)
 {
   printf("%d  ",trav->data);
   trav=trav->next;
 }
 printf("\n");
}
  
void main()
{
  int ch,k=0;
  while(1)
  {

    printf("1.Insert Front\n2.Insert End\n3.Delete Front\n4.Delete End\n5.Rotate\n6. Display\n7.Exit\n");
    scanf("%d",&ch);
    switch(ch)
    {
      case 1:
      insertf();
      break;
      case 2:
      inserte();
      break;
      case 3:
      printf("%d",delf());
      break;
      case 4:
      printf("%d",dele());
      break;
      case 5:
      printf("Enter the index of rotation:");
      scanf("%d",&k);
      rotate(k);
      break;
      case 6:
      display();
      break;
      case 7:
      exit(0);
      break;
      default:
      printf("Wrong Choice");
      break;
    }
  }
}

  
 
