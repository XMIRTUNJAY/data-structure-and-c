
/*  program to implement  stacks  using two queues */

#include <stdio.h>
#include <stdlib.h>
#define QM 100
typedef struct _queue_t {
    int *arr;
    int rear, front, count, max;
} queue_t;
 
/*function prototypes */
queue_t *qallocate(int n);
void qinsert(queue_t * q, int v);
int qremove(queue_t * q);
int qcount(queue_t * q);
int qisempty(queue_t * q);
 

void stackpush(queue_t * q, int v) {
    qinsert(q, v);
}
 
int stackpop(queue_t * q) {
    int i, n = qcount(q);
    int relement;
 
    for (i = 0; i < (n - 1); i++) {
        relement = qremove(q);
        qinsert(q, relement);
       
    }
    relement = qremove(q);
 
    return relement;
}
 
int stackisempty(queue_t * q) {
    return qisempty(q);
}
 
int stackcount(queue_t * q) {
    return qcount(q);
}
 

 
int qcount(queue_t * q) {
    return q->count;
}
 
queue_t *qallocate(int n) {
    queue_t *queue;
 
    queue = malloc(sizeof(queue_t));
    if (queue == NULL)
        return NULL;
    queue->max = n;
 
    queue->arr = malloc(sizeof(int) * n);
    queue->rear = n - 1;
    queue->front = n - 1;
 
    return queue;
}
 
void qinsert(queue_t * q, int v) {
    if (q->count == q->max)
        return;
 
    q->rear = (q->rear + 1) % q->max;
    q->arr[q->rear] = v;
    q->count++;
}
 
int qremove(queue_t * q) {
    int retval;
 
    /* QM number if queue is empty */
    if (q->count == 0)
        return QM;
 
    q->front = (q->front + 1) % q->max;
    retval = q->arr[q->front];
    q->count--;
 
    return retval;
}
 
int qisempty(queue_t * q) {
    return (q->count == 0);
}
 

 

void queue_display(queue_t * q) {
    int i = (q->front + 1) % q->max, elements = qcount(q);
 
    while (elements--) {
        printf("[%d], ", q->arr[i]);
        i = (i >= q->max) ? 0 : (i + 1);
    }
}
 
#define MAX 128
int main(void) {
    queue_t *q;
    int x, select;
    
    q = qallocate(MAX);
 
    do {
        printf("\n[1] Push\n[2] Pop\n[0] Exit");
        printf("\nChoice: ");
        scanf(" %d", &select);
 
        switch (select) {
        case 1:
            printf("\nEnter value to Push:");
            scanf(" %d", &x);
            /* Pushing */
            stackpush(q, x);
 
           
            queue_display(q);
            printf("\n\nPushed Value: %d", x);
 
            
            break;
 
        case 2:
          
            x = stackpop(q);
 
            
            queue_display(q);
            if (x == QM)
                printf("\n\nNo values removed");
            else
                printf("\n\nPopped Value: %d", x);
 
           
            break;
 
        case 0:
            printf("\n");
            return 0;
 
        default:
            printf("\n");
            return 0;
        }
    } while (1);
 
    return 0;
}
